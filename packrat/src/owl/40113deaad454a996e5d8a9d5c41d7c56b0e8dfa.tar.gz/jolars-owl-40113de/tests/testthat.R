library(testthat)
library(owl)

test_check("owl")
