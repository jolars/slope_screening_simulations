# owl 0.1.1

## Minor changes

* A reference to Bogdan et al. (2015) has been added to the description of the 
  package.

## Bug fixes

* The URL in the readme pointing to the code of conduct is now absolute.

# owl 0.1.0

* First release of owl.
