
<!-- README.md is generated from README.Rmd. Please edit that file -->

# rdatasets

<!-- badges: start -->

[![Travis build
status](https://travis-ci.org/jolars/rdatasets.svg?branch=master)](https://travis-ci.org/jolars/rdatasets)
<!-- badges: end -->

A range of datasets for use in R.

## Installation

You can install the development version from
[GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("jolars/rdatasets")
```
